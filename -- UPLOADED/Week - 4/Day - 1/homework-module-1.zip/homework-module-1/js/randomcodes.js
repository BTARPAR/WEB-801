/* ------- RANDOM CODES ------ */

// function to generate combination of characters
function generateCode() {
  var code = ''
  var str = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789@#$'
  var charactersLength = str.length
  for (var i = 0; i < 8; i++) {
    // Generate random index
    var char = Math.random() * charactersLength
    // get character from the particular index of str
    code += str.charAt(char)
  }
  return code
}

// Get HTML element to display
document.getElementById('codes').innerHTML = generateCode()

// Disabled Button
function disableButton() {
  document.getElementById('submit').disabled = true
}

//Activate Button
disableButton()
