$(document).ready(function () {
  // Click only on those <td> which does not contains Not Available text
  $('td:not(:contains("Not Available"))').click(function () {
    $(this).toggleClass('green')
  })
  // Change mouse pointer on hover when, <td> is not first-child in any element
  // And should not contains Not Available text
  $('td:not(:first-child, :contains("Not Available"))').hover(function () {
    $(this).css('cursor', 'pointer')
  })
})
